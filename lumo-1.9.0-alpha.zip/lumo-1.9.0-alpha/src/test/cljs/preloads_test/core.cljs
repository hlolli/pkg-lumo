(ns preloads-test.core)

(def foo :foo)
