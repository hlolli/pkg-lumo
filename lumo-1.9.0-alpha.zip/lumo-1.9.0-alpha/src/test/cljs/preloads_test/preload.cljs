(ns preloads-test.preload)

(def preload-var :foo)
