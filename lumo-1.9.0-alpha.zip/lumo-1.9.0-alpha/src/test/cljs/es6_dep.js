import {default as calc} from './calculator';

export var calculator = calc;
