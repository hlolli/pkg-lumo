(ns libs-test.core
  (:require [tabby]))

(enable-console-print!)

(println (tabby/hello))
