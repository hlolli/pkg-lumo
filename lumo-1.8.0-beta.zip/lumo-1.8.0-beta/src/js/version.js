/* @flow */

// $FlowFixMe: this is replaced at build time
export default (process.env.LUMO_VERSION: string);
