/* @flow */

import startCLI from './cli';

startCLI();
