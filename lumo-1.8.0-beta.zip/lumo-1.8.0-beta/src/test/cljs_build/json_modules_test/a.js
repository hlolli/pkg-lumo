// b is a .json module
var theJSON = require('./b');
