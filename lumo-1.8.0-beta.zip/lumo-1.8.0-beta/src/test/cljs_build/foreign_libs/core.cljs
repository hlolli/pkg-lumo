(ns foreign-libs.core
  (:require [thirdparty.add]))

(enable-console-print!)

(println (js/add 1 2))
