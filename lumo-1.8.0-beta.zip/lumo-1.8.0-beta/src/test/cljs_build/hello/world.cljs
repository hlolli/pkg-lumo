(ns hello.world)
(defn ^:export greet [n]
  (str "Hello " n))
