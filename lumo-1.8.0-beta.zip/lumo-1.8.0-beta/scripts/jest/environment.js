/* eslint-disable */
global.__DEV__ = true;
